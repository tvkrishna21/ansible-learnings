As we are IaC on AWS s3 no other vms are needed
Install the collections for aws from ansible-galaxy
